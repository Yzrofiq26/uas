struct Mahasiswa {
    string nama;
    double ipk;
};

// Struktur Node
struct Node {
    Mahasiswa mhs;
    Node* next;
};